function p = cdps(dir)
p = ['e:\matlab\toolbox\'dir];
cd(p)