function s=shit(x)
s.NumStates = 0;
    s.a = [];
    s.b=[];
    s.c = [];
    s.d = [];
    s.NumInputs = 0;
    s.NumOutputs = 0;
    s = class(s,'stsp');
    return