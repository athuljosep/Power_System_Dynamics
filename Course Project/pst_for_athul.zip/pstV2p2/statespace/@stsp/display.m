function display(s)
% the state space display function
disp(' ')
disp([inputname(1),' ='])
disp(' ') 
get(s)
disp(' ')
