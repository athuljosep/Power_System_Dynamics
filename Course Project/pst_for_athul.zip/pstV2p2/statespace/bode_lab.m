function s=bode_lab
% labels a bode plot
s=1;
subplot(2,1,1);ylabel('gain db')
subplot(2,1,2);ylabel('phase degrees');xlabel('frequency Hz');