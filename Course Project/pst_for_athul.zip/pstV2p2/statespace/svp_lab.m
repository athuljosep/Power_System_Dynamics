function s=svp_lab
% labels a singular value response plot
subplot(2,1,1);title('a')
subplot(2,1,2);title('b');xlabel('frequency Hz');
s=[];