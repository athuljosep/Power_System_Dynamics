% labels an argand diagram
xlabel('real');ylabel('imaginary');