D. Trudnowski.
Jan. 2017

psfv2p2 is a modified version of pstv2p1:  added generator tripping.
1. modified s_simu_Batch.m to include adjustments to the reduced Y matrices to implement a gen. trip.
2. added a call to mac_trip_logic.m to implement tripping algorithms.

See notes folder C:\Users\dtrudnowski\Documents\2015_16\Consulting\GPAproject\ATR which includes examples for an ATR.  
